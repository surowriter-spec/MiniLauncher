# Mini Launcher 2.0 (Aero)

A Vista-Aero-inspired Android home screen with original artwork: aurora wallpaper, glass taskbar, glowing orb Start button, Start menu with search, analog clock gadget, desktop icons. Stock Android underneath, so all APKs and UPI apps work as usual.

- Tap the orb (or swipe up) → Start menu with all apps + Start Search
- Long-press any app → Pin to desktop / Hide / App info / Uninstall
- First 4 pinned apps also appear on the taskbar
- Start menu → "Wallpaper: Aurora/Phone" switches backgrounds
- Tap the clock gadget or taskbar time → Clock app
