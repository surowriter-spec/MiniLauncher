# Mini Launcher

A clean, minimal Android home screen: big clock and date, up to 6 pinned apps, swipe up for the full app list, and long-press to hide apps.

## Install
1. Open the **Actions** tab on GitHub, open the latest "Build APK" run, and download **MiniLauncher-apk** under Artifacts.
2. Unzip it and install `app-debug.apk` (allow "Install unknown apps" if asked).
3. Press the Home button and choose **Mini Launcher** → **Always**.
   Or: Settings → Apps → Default apps → Home app → Mini Launcher.

## Use
- **Swipe up** (or tap "swipe up for apps") → all apps
- **Long-press** an app → Pin to home / Hide / App info / Uninstall
- **Hidden apps** button at the bottom of the drawer → open or unhide them
- **Back** or tap "All apps" → close the drawer

To go back to your old launcher, change the Home app in Settings. Mini Launcher is a normal app, so every APK and UPI app works as usual.
