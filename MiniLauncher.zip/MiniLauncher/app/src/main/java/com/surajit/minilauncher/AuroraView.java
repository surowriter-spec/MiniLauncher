package com.surajit.minilauncher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

/** An original glowing aurora wallpaper, painted once into a bitmap. */
public class AuroraView extends View {

    private Bitmap art;

    public AuroraView(Context c) { super(c); }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w <= 0 || h <= 0) return;
        if (art != null) art.recycle();
        art = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        paintArt(new Canvas(art), w, h);
    }

    private void paintArt(Canvas c, int w, int h) {
        float d = getResources().getDisplayMetrics().density;

        // Deep night-sky base
        Paint base = new Paint();
        base.setShader(new LinearGradient(0, 0, 0, h,
                new int[]{0xFF020A18, 0xFF06294A, 0xFF041A2E, 0xFF01060E},
                new float[]{0f, 0.45f, 0.75f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, base);

        // Soft coloured glows
        glow(c, w * 0.15f, h * 0.30f, w * 0.85f, 0x5522C08A);
        glow(c, w * 0.85f, h * 0.55f, w * 0.90f, 0x552A7BD6);
        glow(c, w * 0.50f, h * 0.85f, w * 0.80f, 0x3348E0C0);
        glow(c, w * 0.70f, h * 0.15f, w * 0.55f, 0x3366A8FF);

        // Flowing light ribbons
        ribbon(c, w, h, d, 0.20f, 0.70f, 0.45f, 0xFF39E3A6, 0x00000000, 90 * d, 40);
        ribbon(c, w, h, d, 0.35f, 0.62f, 0.30f, 0xFF4FC3F7, 0x00000000, 60 * d, 45);
        ribbon(c, w, h, d, 0.55f, 0.80f, 0.60f, 0xFF7CFFCB, 0x00000000, 40 * d, 35);
        ribbon(c, w, h, d, 0.10f, 0.50f, 0.20f, 0xFF2E8BFF, 0x00000000, 120 * d, 30);

        // Thin bright strands
        strand(c, w, h, d, 0.42f, 0.66f, 0.36f, 0xAAFFFFFF);
        strand(c, w, h, d, 0.48f, 0.72f, 0.42f, 0x66C8FFF0);
        strand(c, w, h, d, 0.30f, 0.58f, 0.26f, 0x55B3E5FC);

        // A few faint stars
        Paint star = new Paint(Paint.ANTI_ALIAS_FLAG);
        java.util.Random rnd = new java.util.Random(7);
        for (int i = 0; i < 70; i++) {
            star.setColor(((20 + rnd.nextInt(90)) << 24) | 0xFFFFFF);
            c.drawCircle(rnd.nextFloat() * w, rnd.nextFloat() * h * 0.55f, (0.6f + rnd.nextFloat()) * d, star);
        }
    }

    private void glow(Canvas c, float cx, float cy, float r, int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new RadialGradient(cx, cy, r, color, 0x00000000, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r, p);
    }

    /** A wide blurred S-curve sweeping left to right across the screen. */
    private void ribbon(Canvas c, int w, int h, float d, float yStart, float yMid, float yEnd,
                        int color, int end, float width, int alpha) {
        Path path = curve(w, h, yStart, yMid, yEnd);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(width);
        p.setShader(new LinearGradient(0, 0, w, 0,
                new int[]{end, color, color, end}, new float[]{0f, 0.3f, 0.7f, 1f},
                Shader.TileMode.CLAMP));
        p.setAlpha(alpha);
        p.setMaskFilter(new BlurMaskFilter(Math.max(1f, width * 0.45f), BlurMaskFilter.Blur.NORMAL));
        c.drawPath(path, p);
    }

    private void strand(Canvas c, int w, int h, float d, float yStart, float yMid, float yEnd, int color) {
        Path path = curve(w, h, yStart, yMid, yEnd);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.4f * d);
        p.setShader(new LinearGradient(0, 0, w, 0,
                new int[]{0x00FFFFFF, color, 0x00FFFFFF}, null, Shader.TileMode.CLAMP));
        p.setMaskFilter(new BlurMaskFilter(1.5f * d, BlurMaskFilter.Blur.NORMAL));
        c.drawPath(path, p);
    }

    private Path curve(int w, int h, float yStart, float yMid, float yEnd) {
        Path path = new Path();
        path.moveTo(-w * 0.1f, h * yStart);
        path.cubicTo(w * 0.30f, h * (yMid + 0.12f),
                w * 0.65f, h * (yMid - 0.18f),
                w * 1.1f, h * yEnd);
        return path;
    }

    @Override
    protected void onDraw(Canvas c) {
        if (art != null) c.drawBitmap(art, 0, 0, null);
    }
}
