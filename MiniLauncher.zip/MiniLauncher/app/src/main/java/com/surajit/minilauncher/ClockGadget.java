package com.surajit.minilauncher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

import java.util.Calendar;

/** A desktop-gadget style analog clock with a glossy glass face. */
public class ClockGadget extends View {

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            invalidate();
            postDelayed(this, 1000 - (System.currentTimeMillis() % 1000));
        }
    };

    public ClockGadget(Context c) { super(c); }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        post(tick);
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(tick);
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h / 2f;
        float r = Math.min(w, h) / 2f * 0.92f;

        // Metallic rim
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, cy - r, 0, cy + r,
                new int[]{0xFF9FB4C8, 0xFF2C3E52, 0xFF7E93A8}, null, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r, p);

        // Face
        float fr = r * 0.88f;
        p.setShader(new RadialGradient(cx, cy - fr * 0.3f, fr * 1.3f,
                new int[]{0xFFFFFFFF, 0xFFE3EEF7, 0xFFB8CCDD}, new float[]{0f, 0.6f, 1f},
                Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, fr, p);
        p.setShader(null);

        // Hour ticks
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        for (int i = 0; i < 12; i++) {
            double a = Math.toRadians(i * 30);
            boolean major = i % 3 == 0;
            p.setColor(major ? 0xFF1C2B3A : 0xFF6D8094);
            p.setStrokeWidth(fr * (major ? 0.05f : 0.025f));
            float r1 = fr * (major ? 0.74f : 0.80f), r2 = fr * 0.90f;
            c.drawLine(cx + (float) Math.sin(a) * r1, cy - (float) Math.cos(a) * r1,
                    cx + (float) Math.sin(a) * r2, cy - (float) Math.cos(a) * r2, p);
        }

        Calendar now = Calendar.getInstance();
        float sec = now.get(Calendar.SECOND);
        float min = now.get(Calendar.MINUTE) + sec / 60f;
        float hr = (now.get(Calendar.HOUR) + min / 60f);

        hand(c, cx, cy, hr * 30f, fr * 0.48f, fr * 0.075f, 0xFF15212E);
        hand(c, cx, cy, min * 6f, fr * 0.70f, fr * 0.05f, 0xFF15212E);
        hand(c, cx, cy, sec * 6f, fr * 0.78f, fr * 0.02f, 0xFFD0342C);

        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFD0342C);
        c.drawCircle(cx, cy, fr * 0.06f, p);

        // Glass gloss
        oval.set(cx - fr * 0.80f, cy - fr * 0.95f, cx + fr * 0.80f, cy + fr * 0.05f);
        p.setShader(new LinearGradient(0, oval.top, 0, oval.bottom,
                0x99FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawOval(oval, p);
        p.setShader(null);
    }

    private void hand(Canvas c, float cx, float cy, float deg, float len, float width, int color) {
        double a = Math.toRadians(deg);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(width);
        p.setColor(color);
        c.drawLine(cx - (float) Math.sin(a) * len * 0.15f, cy + (float) Math.cos(a) * len * 0.15f,
                cx + (float) Math.sin(a) * len, cy - (float) Math.cos(a) * len, p);
    }
}
