package com.surajit.minilauncher;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/**
 * A see-through "Aero glass" panel: tinted translucent body, a glossy
 * highlight over the top half, a dark outer edge and a light inner edge.
 */
public class Glass extends Drawable {

    private final Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gloss = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint outer = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint inner = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final RectF innerRect = new RectF();
    private final float radius;
    private final float px;
    private final int tint;

    /**
     * @param radius corner radius in pixels
     * @param tint   ARGB colour of the glass body (use alpha for see-through)
     * @param px     one dp in pixels
     */
    public Glass(float radius, int tint, float px) {
        this.radius = radius;
        this.tint = tint;
        this.px = px;

        outer.setStyle(Paint.Style.STROKE);
        outer.setStrokeWidth(px);
        outer.setColor(0x99000000);

        inner.setStyle(Paint.Style.STROKE);
        inner.setStrokeWidth(px);
        inner.setColor(0x55FFFFFF);
    }

    @Override
    protected void onBoundsChange(Rect b) {
        super.onBoundsChange(b);
        rect.set(b.left + px / 2f, b.top + px / 2f, b.right - px / 2f, b.bottom - px / 2f);
        innerRect.set(rect.left + px, rect.top + px, rect.right - px, rect.bottom - px);

        int top = lighten(tint, 0.18f);
        body.setShader(new LinearGradient(0, b.top, 0, b.bottom, top, tint, Shader.TileMode.CLAMP));

        float mid = b.top + b.height() * 0.5f;
        gloss.setShader(new LinearGradient(0, b.top, 0, mid,
                0x40FFFFFF, 0x0DFFFFFF, Shader.TileMode.CLAMP));
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        c.drawRoundRect(rect, radius, radius, body);

        int save = c.save();
        c.clipRect(b.left, b.top, b.right, b.top + b.height() * 0.5f);
        c.drawRoundRect(innerRect, radius, radius, gloss);
        c.restoreToCount(save);

        c.drawRoundRect(innerRect, Math.max(0, radius - px), Math.max(0, radius - px), inner);
        c.drawRoundRect(rect, radius, radius, outer);
    }

    private static int lighten(int color, float amount) {
        int a = (color >>> 24) & 0xFF;
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int bl = color & 0xFF;
        r = (int) (r + (255 - r) * amount);
        g = (int) (g + (255 - g) * amount);
        bl = (int) (bl + (255 - bl) * amount);
        return (a << 24) | (r << 16) | (g << 8) | bl;
    }

    @Override public void setAlpha(int alpha) { body.setAlpha(alpha); invalidateSelf(); }
    @Override public void setColorFilter(ColorFilter cf) { body.setColorFilter(cf); invalidateSelf(); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
