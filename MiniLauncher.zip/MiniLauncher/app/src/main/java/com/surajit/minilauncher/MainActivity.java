package com.surajit.minilauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {

    private static final String PREFS = "launcher";
    private static final String KEY_HIDDEN = "hidden";
    private static final String KEY_FAVS = "favs";
    private static final int MAX_FAVS = 6;

    private View home, drawer;
    private LinearLayout favBox;
    private ListView appList;
    private TextView hiddenBtn;
    private SharedPreferences prefs;
    private GestureDetector gestures;

    private final List<AppItem> visibleApps = new ArrayList<>();
    private final Map<String, AppItem> allApps = new HashMap<>();
    private AppAdapter adapter;
    private BroadcastReceiver packageReceiver;

    /** One installed app. */
    static class AppItem {
        final String label, pkg, cls;
        final Drawable icon;

        AppItem(String label, String pkg, String cls, Drawable icon) {
            this.label = label;
            this.pkg = pkg;
            this.cls = cls;
            this.icon = icon;
        }

        String key() { return pkg + "/" + cls; }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        home = findViewById(R.id.home);
        drawer = findViewById(R.id.drawer);
        favBox = findViewById(R.id.favs);
        appList = findViewById(R.id.app_list);
        hiddenBtn = findViewById(R.id.hidden_btn);

        adapter = new AppAdapter();
        appList.setAdapter(adapter);
        appList.setOnItemClickListener((p, v, pos, id) -> launch(visibleApps.get(pos)));
        appList.setOnItemLongClickListener((p, v, pos, id) -> {
            showAppOptions(visibleApps.get(pos));
            return true;
        });

        findViewById(R.id.hint).setOnClickListener(v -> openDrawer());
        findViewById(R.id.drawer_title).setOnClickListener(v -> closeDrawer());
        hiddenBtn.setOnClickListener(v -> showHiddenApps());

        // Swipe up anywhere on the home screen opens the app drawer
        gestures = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDown(MotionEvent e) { return true; }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (e1 == null) return false;
                float dy = e2.getY() - e1.getY();
                float dx = e2.getX() - e1.getX();
                if (dy < -150 && Math.abs(dy) > Math.abs(dx) && Math.abs(vy) > 500) {
                    openDrawer();
                    return true;
                }
                return false;
            }
        });

        // Refresh the list when apps are installed or removed
        packageReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) { loadApps(); }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addAction(Intent.ACTION_PACKAGE_REPLACED);
        f.addDataScheme("package");
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(packageReceiver, f, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(packageReceiver, f);
        }

        loadApps();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadApps();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Pressing the Home button brings you back to the clock
        closeDrawer();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(packageReceiver); } catch (Exception ignored) { }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (drawer.getVisibility() != View.VISIBLE) gestures.onTouchEvent(ev);
        return super.dispatchTouchEvent(ev);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        // Back closes the drawer; on the home screen it does nothing
        if (drawer.getVisibility() == View.VISIBLE) closeDrawer();
    }

    // ---------- Drawer ----------

    private void openDrawer() {
        if (drawer.getVisibility() == View.VISIBLE) return;
        drawer.setAlpha(0f);
        drawer.setTranslationY(120f);
        drawer.setVisibility(View.VISIBLE);
        drawer.animate().alpha(1f).translationY(0f).setDuration(180).start();
        appList.setSelection(0);
    }

    private void closeDrawer() {
        if (drawer.getVisibility() != View.VISIBLE) return;
        drawer.animate().alpha(0f).translationY(120f).setDuration(150)
                .withEndAction(() -> drawer.setVisibility(View.GONE)).start();
    }

    // ---------- Loading apps ----------

    private void loadApps() {
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            Intent query = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> found = pm.queryIntentActivities(query, 0);

            Map<String, AppItem> map = new HashMap<>();
            for (ResolveInfo ri : found) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName())) continue;
                AppItem a = new AppItem(
                        String.valueOf(ri.loadLabel(pm)),
                        pkg,
                        ri.activityInfo.name,
                        ri.loadIcon(pm));
                map.put(a.key(), a);
            }

            runOnUiThread(() -> {
                allApps.clear();
                allApps.putAll(map);
                refreshLists();
            });
        }).start();
    }

    private void refreshLists() {
        Set<String> hidden = getHidden();
        visibleApps.clear();
        int hiddenCount = 0;
        for (AppItem a : allApps.values()) {
            if (hidden.contains(a.key())) hiddenCount++;
            else visibleApps.add(a);
        }
        Collator c = Collator.getInstance();
        visibleApps.sort((x, y) -> c.compare(x.label, y.label));
        adapter.notifyDataSetChanged();

        if (hiddenCount > 0) {
            hiddenBtn.setText("Hidden apps (" + hiddenCount + ")");
            hiddenBtn.setVisibility(View.VISIBLE);
        } else {
            hiddenBtn.setVisibility(View.GONE);
        }
        renderFavs();
    }

    // ---------- Home screen favourites ----------

    private void renderFavs() {
        favBox.removeAllViews();
        Set<String> hidden = getHidden();
        int shown = 0;
        for (String key : getFavs()) {
            AppItem a = allApps.get(key);
            if (a == null || hidden.contains(key)) continue;
            TextView tv = new TextView(this);
            tv.setText(a.label);
            tv.setTextColor(getColor(R.color.text_main));
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
            tv.setShadowLayer(4, 0, 1, 0x66000000);
            int pad = dp(10);
            tv.setPadding(0, pad, 0, pad);
            tv.setOnClickListener(v -> launch(a));
            tv.setOnLongClickListener(v -> {
                showAppOptions(a);
                return true;
            });
            favBox.addView(tv);
            shown++;
        }
        if (shown == 0) {
            TextView tv = new TextView(this);
            tv.setText(R.string.empty_favs);
            tv.setTextColor(getColor(R.color.text_dim));
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            favBox.addView(tv);
        }
    }

    // ---------- Long-press menu ----------

    private void showAppOptions(AppItem a) {
        List<String> favs = getFavs();
        boolean isFav = favs.contains(a.key());
        boolean isHidden = getHidden().contains(a.key());
        String[] options = {
                isFav ? "Remove from home screen" : "Pin to home screen",
                isHidden ? "Unhide app" : "Hide app",
                "App info",
                "Uninstall"
        };
        new AlertDialog.Builder(this)
                .setTitle(a.label)
                .setItems(options, (d, which) -> {
                    switch (which) {
                        case 0: toggleFav(a); break;
                        case 1: setHidden(a, !isHidden); break;
                        case 2: openAppInfo(a); break;
                        case 3: uninstall(a); break;
                    }
                })
                .show();
    }

    private void toggleFav(AppItem a) {
        List<String> favs = getFavs();
        if (favs.contains(a.key())) {
            favs.remove(a.key());
        } else {
            if (favs.size() >= MAX_FAVS) {
                toast("Home screen holds " + MAX_FAVS + " apps. Remove one first.");
                return;
            }
            favs.add(a.key());
        }
        prefs.edit().putString(KEY_FAVS, String.join("|", favs)).apply();
        renderFavs();
    }

    private void setHidden(AppItem a, boolean hide) {
        Set<String> hidden = getHidden();
        if (hide) hidden.add(a.key()); else hidden.remove(a.key());
        prefs.edit().putStringSet(KEY_HIDDEN, hidden).apply();
        if (hide) toast(a.label + " hidden");
        refreshLists();
    }

    private void showHiddenApps() {
        Set<String> hidden = getHidden();
        List<AppItem> items = new ArrayList<>();
        for (String key : hidden) {
            AppItem a = allApps.get(key);
            if (a != null) items.add(a);
        }
        if (items.isEmpty()) return;
        Collator c = Collator.getInstance();
        items.sort((x, y) -> c.compare(x.label, y.label));
        String[] names = new String[items.size()];
        for (int i = 0; i < items.size(); i++) names[i] = items.get(i).label;

        new AlertDialog.Builder(this)
                .setTitle("Hidden apps")
                .setItems(names, (d, which) -> showHiddenOptions(items.get(which)))
                .setNegativeButton("Close", null)
                .show();
    }

    private void showHiddenOptions(AppItem a) {
        new AlertDialog.Builder(this)
                .setTitle(a.label)
                .setItems(new String[]{"Open", "Unhide"}, (d, which) -> {
                    if (which == 0) launch(a); else setHidden(a, false);
                })
                .show();
    }

    // ---------- Actions ----------

    private void launch(AppItem a) {
        Intent i = new Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(new ComponentName(a.pkg, a.cls))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try {
            startActivity(i);
        } catch (ActivityNotFoundException | SecurityException e) {
            toast("Couldn't open " + a.label);
        }
    }

    private void openAppInfo(AppItem a) {
        try {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", a.pkg, null)));
        } catch (Exception e) {
            toast("Couldn't open app info");
        }
    }

    private void uninstall(AppItem a) {
        try {
            startActivity(new Intent(Intent.ACTION_DELETE, Uri.fromParts("package", a.pkg, null)));
        } catch (Exception e) {
            toast("This app can't be uninstalled");
        }
    }

    // ---------- Helpers ----------

    private Set<String> getHidden() {
        return new HashSet<>(prefs.getStringSet(KEY_HIDDEN, new HashSet<>()));
    }

    private List<String> getFavs() {
        String raw = prefs.getString(KEY_FAVS, "");
        List<String> out = new ArrayList<>();
        if (!raw.isEmpty()) out.addAll(Arrays.asList(raw.split("\\|")));
        return out;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    // ---------- Drawer list adapter ----------

    private class AppAdapter extends BaseAdapter {
        @Override public int getCount() { return visibleApps.size(); }
        @Override public Object getItem(int p) { return visibleApps.get(p); }
        @Override public long getItemId(int p) { return p; }

        @Override
        public View getView(int pos, View row, ViewGroup parent) {
            if (row == null) {
                row = LayoutInflater.from(MainActivity.this).inflate(R.layout.item_app, parent, false);
            }
            AppItem a = visibleApps.get(pos);
            ((ImageView) row.findViewById(R.id.icon)).setImageDrawable(a.icon);
            ((TextView) row.findViewById(R.id.label)).setText(a.label);
            return row;
        }
    }
}
