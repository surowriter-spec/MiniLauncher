package com.surajit.minilauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {

    private static final String PREFS = "launcher";
    private static final String KEY_HIDDEN = "hidden";
    private static final String KEY_FAVS = "favs";
    private static final String KEY_WALL = "use_phone_wallpaper";
    private static final int MAX_PINS = 12;
    private static final int PER_COLUMN = 6;
    private static final int QUICK_LAUNCH = 4;
    private static final int TASKBAR_DP = 56;

    private SharedPreferences prefs;
    private GestureDetector gestures;
    private BroadcastReceiver packageReceiver;

    private AuroraView aurora;
    private LinearLayout desktop, quickLaunch, startMenu;
    private View scrim;
    private OrbView orb;
    private ListView appList;
    private EditText search;
    private TextView hiddenLink, wallLink;

    private final Map<String, AppItem> allApps = new HashMap<>();
    private final List<AppItem> visibleApps = new ArrayList<>();
    private final List<AppItem> shownApps = new ArrayList<>();
    private AppAdapter adapter;

    /** One installed app. */
    static class AppItem {
        final String label, pkg, cls;
        final Drawable icon;

        AppItem(String label, String pkg, String cls, Drawable icon) {
            this.label = label;
            this.pkg = pkg;
            this.cls = cls;
            this.icon = icon;
        }

        String key() { return pkg + "/" + cls; }
    }

    // =====================================================================
    // Lifecycle
    // =====================================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        setContentView(buildUi());
        applyWallpaperChoice();

        gestures = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (e1 == null) return false;
                float dy = e2.getY() - e1.getY();
                float dx = e2.getX() - e1.getX();
                if (dy < -150 && Math.abs(dy) > Math.abs(dx) && Math.abs(vy) > 500) {
                    openStart();
                    return true;
                }
                return false;
            }
        });

        packageReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) { loadApps(); }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addAction(Intent.ACTION_PACKAGE_REPLACED);
        f.addDataScheme("package");
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(packageReceiver, f, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(packageReceiver, f);
        }

        loadApps();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadApps();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        closeStart();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(packageReceiver); } catch (Exception ignored) { }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (startMenu.getVisibility() != View.VISIBLE) gestures.onTouchEvent(ev);
        return super.dispatchTouchEvent(ev);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (startMenu.getVisibility() == View.VISIBLE) closeStart();
    }

    // =====================================================================
    // Building the screen
    // =====================================================================

    private View buildUi() {
        float px = dp(1);
        FrameLayout root = new FrameLayout(this);

        aurora = new AuroraView(this);
        root.addView(aurora, new FrameLayout.LayoutParams(-1, -1));

        FrameLayout content = new FrameLayout(this);
        content.setFitsSystemWindows(true);
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));

        // ---- Desktop icons (left side) ----
        desktop = new LinearLayout(this);
        desktop.setOrientation(LinearLayout.HORIZONTAL);
        desktop.setPadding(dp(6), dp(14), dp(6), dp(6));
        FrameLayout.LayoutParams dl = new FrameLayout.LayoutParams(-2, -1, Gravity.START | Gravity.TOP);
        dl.bottomMargin = dp(TASKBAR_DP);
        content.addView(desktop, dl);

        // ---- Clock gadget (top right) ----
        LinearLayout gadget = new LinearLayout(this);
        gadget.setOrientation(LinearLayout.VERTICAL);
        gadget.setGravity(Gravity.CENTER_HORIZONTAL);
        gadget.setPadding(dp(12), dp(12), dp(12), dp(10));
        gadget.setBackground(new Glass(dp(16), 0x5514304E, px));

        ClockGadget clock = new ClockGadget(this);
        gadget.addView(clock, new LinearLayout.LayoutParams(dp(118), dp(118)));

        TextClock day = new TextClock(this);
        day.setFormat12Hour("EEEE");
        day.setFormat24Hour("EEEE");
        styleLight(day, 16, true);
        day.setPadding(0, dp(6), 0, 0);
        gadget.addView(day);

        TextClock date = new TextClock(this);
        date.setFormat12Hour("d MMMM yyyy");
        date.setFormat24Hour("d MMMM yyyy");
        styleLight(date, 12, false);
        gadget.addView(date);

        gadget.setOnClickListener(v -> openClockApp());
        FrameLayout.LayoutParams gl = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        gl.topMargin = dp(14);
        gl.rightMargin = dp(12);
        content.addView(gadget, gl);

        // ---- Dim layer behind the Start menu ----
        scrim = new View(this);
        scrim.setBackgroundColor(0x44000000);
        scrim.setVisibility(View.GONE);
        scrim.setOnClickListener(v -> closeStart());
        content.addView(scrim, new FrameLayout.LayoutParams(-1, -1));

        // ---- Start menu ----
        startMenu = buildStartMenu(px);
        int sw = getResources().getDisplayMetrics().widthPixels;
        int sh = getResources().getDisplayMetrics().heightPixels;
        FrameLayout.LayoutParams sl = new FrameLayout.LayoutParams(
                Math.min(sw - dp(12), dp(420)), (int) (sh * 0.68f), Gravity.BOTTOM | Gravity.START);
        sl.leftMargin = dp(6);
        sl.bottomMargin = dp(TASKBAR_DP + 4);
        startMenu.setVisibility(View.GONE);
        content.addView(startMenu, sl);

        // ---- Taskbar ----
        content.addView(buildTaskbar(px),
                new FrameLayout.LayoutParams(-1, dp(TASKBAR_DP), Gravity.BOTTOM));

        return root;
    }

    private LinearLayout buildTaskbar(float px) {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackground(new Glass(0, 0xC0061222, px));

        orb = new OrbView(this);
        orb.setOnClickListener(v -> toggleStart());
        LinearLayout.LayoutParams ol = new LinearLayout.LayoutParams(dp(56), dp(56));
        ol.leftMargin = dp(2);
        bar.addView(orb, ol);

        quickLaunch = new LinearLayout(this);
        quickLaunch.setOrientation(LinearLayout.HORIZONTAL);
        quickLaunch.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams ql = new LinearLayout.LayoutParams(-2, -1);
        ql.leftMargin = dp(4);
        bar.addView(quickLaunch, ql);

        bar.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));

        View sep = new View(this);
        sep.setBackgroundColor(0x33FFFFFF);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(Math.max(1, dp(1)), dp(30));
        sp.rightMargin = dp(10);
        bar.addView(sep, sp);

        LinearLayout tray = new LinearLayout(this);
        tray.setOrientation(LinearLayout.VERTICAL);
        tray.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        tray.setPadding(0, 0, dp(12), 0);

        TextClock time = new TextClock(this);
        time.setFormat12Hour("h:mm a");
        time.setFormat24Hour("HH:mm");
        styleLight(time, 13, false);
        time.setGravity(Gravity.END);
        tray.addView(time);

        TextClock small = new TextClock(this);
        small.setFormat12Hour("dd-MM-yyyy");
        small.setFormat24Hour("dd-MM-yyyy");
        styleLight(small, 11, false);
        small.setTextColor(0xBBFFFFFF);
        small.setGravity(Gravity.END);
        tray.addView(small);

        tray.setOnClickListener(v -> openClockApp());
        bar.addView(tray, new LinearLayout.LayoutParams(-2, -1));
        return bar;
    }

    private LinearLayout buildStartMenu(float px) {
        LinearLayout menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.HORIZONTAL);
        menu.setPadding(dp(6), dp(6), dp(6), dp(6));
        menu.setBackground(new Glass(dp(12), 0xD00A1C30, px));
        menu.setClickable(true);

        // ---- Left: white programs pane ----
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable white = new GradientDrawable();
        white.setColor(0xF7FFFFFF);
        white.setCornerRadius(dp(8));
        white.setStroke(Math.max(1, dp(1)), 0x88000000);
        left.setBackground(white);

        TextView header = new TextView(this);
        header.setText("All Programs");
        header.setTextColor(0xFF1E3D63);
        header.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        header.setTypeface(Typeface.DEFAULT_BOLD);
        header.setPadding(dp(12), dp(10), dp(12), dp(6));
        left.addView(header);

        appList = new ListView(this);
        appList.setDivider(null);
        appList.setVerticalScrollBarEnabled(false);
        appList.setSelector(new ColorDrawable(0x00000000));
        adapter = new AppAdapter();
        appList.setAdapter(adapter);
        appList.setOnItemClickListener((p, v, pos, id) -> launch(shownApps.get(pos)));
        appList.setOnItemLongClickListener((p, v, pos, id) -> {
            showAppOptions(shownApps.get(pos));
            return true;
        });
        left.addView(appList, new LinearLayout.LayoutParams(-1, 0, 1f));

        search = new EditText(this);
        search.setHint("Start Search");
        search.setSingleLine(true);
        search.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        search.setTextColor(0xFF1A1A1A);
        search.setHintTextColor(0xFF8A95A3);
        search.setImeOptions(EditorInfo.IME_ACTION_GO);
        search.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable box = new GradientDrawable();
        box.setColor(0xFFFFFFFF);
        box.setCornerRadius(dp(16));
        box.setStroke(Math.max(1, dp(1)), 0xFF7FA6C9);
        search.setBackground(box);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { filterApps(); }
            @Override public void afterTextChanged(Editable s) { }
        });
        search.setOnEditorActionListener((v, actionId, ev) -> {
            if (!shownApps.isEmpty()) launch(shownApps.get(0));
            return true;
        });
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-1, -2);
        sl.setMargins(dp(8), dp(6), dp(8), dp(8));
        left.addView(search, sl);

        menu.addView(left, new LinearLayout.LayoutParams(0, -1, 1.6f));

        // ---- Right: dark glass links pane ----
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setPadding(dp(8), dp(8), dp(4), dp(8));

        OrbView badge = new OrbView(this);
        badge.setClickable(false);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(dp(54), dp(54));
        bl.gravity = Gravity.CENTER_HORIZONTAL;
        bl.bottomMargin = dp(10);
        right.addView(badge, bl);

        right.addView(link("Phone Settings", v -> openSettings(Settings.ACTION_SETTINGS)));
        right.addView(link("Wi-Fi", v -> openSettings(Settings.ACTION_WIFI_SETTINGS)));
        right.addView(link("Bluetooth", v -> openSettings(Settings.ACTION_BLUETOOTH_SETTINGS)));
        right.addView(divider());
        wallLink = link("", v -> toggleWallpaper());
        right.addView(wallLink);
        hiddenLink = link("Hidden apps", v -> showHiddenApps());
        right.addView(hiddenLink);
        right.addView(divider());
        right.addView(link("Choose home app", v -> openSettings(Settings.ACTION_HOME_SETTINGS)));

        menu.addView(right, new LinearLayout.LayoutParams(0, -1, 1f));
        return menu;
    }

    private TextView link(String text, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        t.setShadowLayer(3, 0, 1, 0x99000000);
        t.setPadding(dp(10), dp(9), dp(8), dp(9));
        t.setBackground(ripple(0x553FB8FF, dp(6)));
        t.setOnClickListener(l);
        return t;
    }

    private View divider() {
        View v = new View(this);
        v.setBackgroundColor(0x33FFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, Math.max(1, dp(1)));
        lp.setMargins(dp(8), dp(6), dp(8), dp(6));
        v.setLayoutParams(lp);
        return v;
    }

    private RippleDrawable ripple(int color, int radius) {
        GradientDrawable mask = new GradientDrawable();
        mask.setColor(Color.WHITE);
        mask.setCornerRadius(radius);
        return new RippleDrawable(ColorStateList.valueOf(color), null, mask);
    }

    private void styleLight(TextView t, int sp, boolean bold) {
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setShadowLayer(4, 0, 1, 0xAA000000);
        if (bold) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
    }

    // =====================================================================
    // Start menu open / close
    // =====================================================================

    private void toggleStart() {
        if (startMenu.getVisibility() == View.VISIBLE) closeStart(); else openStart();
    }

    private void openStart() {
        if (startMenu.getVisibility() == View.VISIBLE) return;
        search.setText("");
        scrim.setVisibility(View.VISIBLE);
        startMenu.setAlpha(0f);
        startMenu.setTranslationY(dp(40));
        startMenu.setVisibility(View.VISIBLE);
        startMenu.animate().alpha(1f).translationY(0f).setDuration(170).start();
        appList.setSelection(0);
        orb.setActive(true);
    }

    private void closeStart() {
        if (startMenu.getVisibility() != View.VISIBLE) return;
        hideKeyboard();
        orb.setActive(false);
        scrim.setVisibility(View.GONE);
        startMenu.animate().alpha(0f).translationY(dp(40)).setDuration(140)
                .withEndAction(() -> startMenu.setVisibility(View.GONE)).start();
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(search.getWindowToken(), 0);
        search.clearFocus();
    }

    // =====================================================================
    // Apps
    // =====================================================================

    private void loadApps() {
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            Intent query = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> found = pm.queryIntentActivities(query, 0);
            Map<String, AppItem> map = new HashMap<>();
            for (ResolveInfo ri : found) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName())) continue;
                AppItem a = new AppItem(String.valueOf(ri.loadLabel(pm)), pkg,
                        ri.activityInfo.name, ri.loadIcon(pm));
                map.put(a.key(), a);
            }
            runOnUiThread(() -> {
                allApps.clear();
                allApps.putAll(map);
                refreshAll();
            });
        }).start();
    }

    private void refreshAll() {
        Set<String> hidden = getHidden();
        visibleApps.clear();
        int hiddenCount = 0;
        for (AppItem a : allApps.values()) {
            if (hidden.contains(a.key())) hiddenCount++;
            else visibleApps.add(a);
        }
        Collator c = Collator.getInstance();
        visibleApps.sort((x, y) -> c.compare(x.label, y.label));
        filterApps();
        hiddenLink.setText(hiddenCount > 0 ? "Hidden apps (" + hiddenCount + ")" : "Hidden apps");
        renderDesktop();
        renderQuickLaunch();
    }

    private void filterApps() {
        String q = search == null ? "" : search.getText().toString().trim().toLowerCase(Locale.ROOT);
        shownApps.clear();
        for (AppItem a : visibleApps) {
            if (q.isEmpty() || a.label.toLowerCase(Locale.ROOT).contains(q)) shownApps.add(a);
        }
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private List<AppItem> pinnedApps() {
        Set<String> hidden = getHidden();
        List<AppItem> out = new ArrayList<>();
        for (String key : getFavs()) {
            AppItem a = allApps.get(key);
            if (a != null && !hidden.contains(key)) out.add(a);
        }
        return out;
    }

    private void renderDesktop() {
        desktop.removeAllViews();
        List<AppItem> pins = pinnedApps();
        if (pins.isEmpty()) {
            TextView hint = new TextView(this);
            hint.setText("Tap the orb, then long-press\nany app to pin it here");
            styleLight(hint, 13, false);
            hint.setPadding(dp(12), dp(10), dp(12), dp(10));
            hint.setBackground(new Glass(dp(10), 0x5514304E, dp(1)));
            LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(-2, -2);
            hl.setMargins(dp(6), dp(6), 0, 0);
            desktop.addView(hint, hl);
            return;
        }
        LinearLayout column = null;
        for (int i = 0; i < pins.size(); i++) {
            if (i % PER_COLUMN == 0) {
                column = new LinearLayout(this);
                column.setOrientation(LinearLayout.VERTICAL);
                desktop.addView(column, new LinearLayout.LayoutParams(dp(84), -2));
            }
            column.addView(desktopIcon(pins.get(i)));
        }
    }

    private View desktopIcon(AppItem a) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(4), dp(6), dp(4), dp(6));
        box.setBackground(ripple(0x4466CCFF, dp(6)));

        ImageView iv = new ImageView(this);
        iv.setImageDrawable(a.icon);
        box.addView(iv, new LinearLayout.LayoutParams(dp(46), dp(46)));

        TextView tv = new TextView(this);
        tv.setText(a.label);
        styleLight(tv, 12, false);
        tv.setGravity(Gravity.CENTER_HORIZONTAL);
        tv.setMaxLines(2);
        tv.setEllipsize(TextUtils.TruncateAt.END);
        tv.setPadding(0, dp(4), 0, 0);
        box.addView(tv, new LinearLayout.LayoutParams(-1, -2));

        box.setOnClickListener(v -> launch(a));
        box.setOnLongClickListener(v -> {
            showAppOptions(a);
            return true;
        });
        return box;
    }

    private void renderQuickLaunch() {
        quickLaunch.removeAllViews();
        List<AppItem> pins = pinnedApps();
        for (int i = 0; i < pins.size() && i < QUICK_LAUNCH; i++) {
            AppItem a = pins.get(i);
            ImageView iv = new ImageView(this);
            iv.setImageDrawable(a.icon);
            iv.setPadding(dp(5), dp(5), dp(5), dp(5));
            iv.setBackground(ripple(0x5566CCFF, dp(8)));
            iv.setContentDescription(a.label);
            iv.setOnClickListener(v -> launch(a));
            iv.setOnLongClickListener(v -> {
                showAppOptions(a);
                return true;
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(42), dp(42));
            lp.leftMargin = dp(2);
            quickLaunch.addView(iv, lp);
        }
    }

    // =====================================================================
    // Long-press menu, pins, hiding
    // =====================================================================

    private void showAppOptions(AppItem a) {
        boolean isPinned = getFavs().contains(a.key());
        boolean isHidden = getHidden().contains(a.key());
        String[] options = {
                isPinned ? "Remove from desktop" : "Pin to desktop",
                isHidden ? "Unhide app" : "Hide app",
                "App info",
                "Uninstall"
        };
        dialog().setTitle(a.label)
                .setItems(options, (d, which) -> {
                    switch (which) {
                        case 0: togglePin(a); break;
                        case 1: setHidden(a, !isHidden); break;
                        case 2: openAppInfo(a); break;
                        case 3: uninstall(a); break;
                        default: break;
                    }
                })
                .show();
    }

    private void togglePin(AppItem a) {
        List<String> favs = getFavs();
        if (favs.contains(a.key())) {
            favs.remove(a.key());
        } else {
            if (favs.size() >= MAX_PINS) {
                toast("Desktop holds " + MAX_PINS + " apps. Remove one first.");
                return;
            }
            favs.add(a.key());
            toast(a.label + " pinned to desktop");
        }
        prefs.edit().putString(KEY_FAVS, TextUtils.join("|", favs)).apply();
        renderDesktop();
        renderQuickLaunch();
    }

    private void setHidden(AppItem a, boolean hide) {
        Set<String> hidden = getHidden();
        if (hide) hidden.add(a.key()); else hidden.remove(a.key());
        prefs.edit().putStringSet(KEY_HIDDEN, hidden).apply();
        if (hide) toast(a.label + " hidden");
        refreshAll();
    }

    private void showHiddenApps() {
        List<AppItem> items = new ArrayList<>();
        for (String key : getHidden()) {
            AppItem a = allApps.get(key);
            if (a != null) items.add(a);
        }
        if (items.isEmpty()) {
            toast("No hidden apps");
            return;
        }
        Collator c = Collator.getInstance();
        items.sort((x, y) -> c.compare(x.label, y.label));
        String[] names = new String[items.size()];
        for (int i = 0; i < items.size(); i++) names[i] = items.get(i).label;
        dialog().setTitle("Hidden apps")
                .setItems(names, (d, which) -> showHiddenOptions(items.get(which)))
                .setNegativeButton("Close", null)
                .show();
    }

    private void showHiddenOptions(AppItem a) {
        dialog().setTitle(a.label)
                .setItems(new String[]{"Open", "Unhide"}, (d, which) -> {
                    if (which == 0) launch(a); else setHidden(a, false);
                })
                .show();
    }

    private AlertDialog.Builder dialog() {
        return new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert);
    }

    // =====================================================================
    // Wallpaper choice
    // =====================================================================

    private void toggleWallpaper() {
        boolean usePhone = !prefs.getBoolean(KEY_WALL, false);
        prefs.edit().putBoolean(KEY_WALL, usePhone).apply();
        applyWallpaperChoice();
    }

    private void applyWallpaperChoice() {
        boolean usePhone = prefs.getBoolean(KEY_WALL, false);
        aurora.setVisibility(usePhone ? View.GONE : View.VISIBLE);
        wallLink.setText(usePhone ? "Wallpaper: Phone" : "Wallpaper: Aurora");
    }

    // =====================================================================
    // Actions
    // =====================================================================

    private void launch(AppItem a) {
        Intent i = new Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(new ComponentName(a.pkg, a.cls))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try {
            startActivity(i);
            closeStart();
        } catch (ActivityNotFoundException | SecurityException e) {
            toast("Couldn't open " + a.label);
        }
    }

    private void openSettings(String action) {
        try {
            startActivity(new Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            closeStart();
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
                closeStart();
            } catch (Exception ignored) {
                toast("Couldn't open settings");
            }
        }
    }

    private void openClockApp() {
        try {
            startActivity(new Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            toast("No clock app found");
        }
    }

    private void openAppInfo(AppItem a) {
        try {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", a.pkg, null)));
        } catch (Exception e) {
            toast("Couldn't open app info");
        }
    }

    private void uninstall(AppItem a) {
        try {
            startActivity(new Intent(Intent.ACTION_DELETE, Uri.fromParts("package", a.pkg, null)));
        } catch (Exception e) {
            toast("This app can't be uninstalled");
        }
    }

    // =====================================================================
    // Helpers
    // =====================================================================

    private Set<String> getHidden() {
        return new HashSet<>(prefs.getStringSet(KEY_HIDDEN, new HashSet<>()));
    }

    private List<String> getFavs() {
        String raw = prefs.getString(KEY_FAVS, "");
        List<String> out = new ArrayList<>();
        if (raw != null && !raw.isEmpty()) out.addAll(Arrays.asList(raw.split("\\|")));
        return out;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    // =====================================================================
    // Start menu list
    // =====================================================================

    private class AppAdapter extends BaseAdapter {
        @Override public int getCount() { return shownApps.size(); }
        @Override public Object getItem(int p) { return shownApps.get(p); }
        @Override public long getItemId(int p) { return p; }

        @Override
        public View getView(int pos, View row, ViewGroup parent) {
            if (row == null) {
                LinearLayout r = new LinearLayout(MainActivity.this);
                r.setOrientation(LinearLayout.HORIZONTAL);
                r.setGravity(Gravity.CENTER_VERTICAL);
                r.setPadding(dp(10), dp(6), dp(8), dp(6));
                r.setBackground(ripple(0x553399FF, dp(4)));

                ImageView iv = new ImageView(MainActivity.this);
                iv.setId(View.generateViewId());
                r.addView(iv, new LinearLayout.LayoutParams(dp(34), dp(34)));

                TextView tv = new TextView(MainActivity.this);
                tv.setTextColor(0xFF1B1F24);
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                tv.setSingleLine(true);
                tv.setEllipsize(TextUtils.TruncateAt.END);
                LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1f);
                tl.leftMargin = dp(12);
                r.addView(tv, tl);

                r.setTag(new View[]{iv, tv});
                row = r;
            }
            View[] parts = (View[]) row.getTag();
            AppItem a = shownApps.get(pos);
            ((ImageView) parts[0]).setImageDrawable(a.icon);
            ((TextView) parts[1]).setText(a.label);
            return row;
        }
    }
}
