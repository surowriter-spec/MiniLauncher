package com.surajit.minilauncher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/** The glowing round Start button: a glossy glass sphere with a light sparkle. */
public class OrbView extends View {

    private boolean active;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();
    private final Path star = new Path();

    public OrbView(Context c) {
        super(c);
        setClickable(true);
        setContentDescription("Start");
    }

    public void setActive(boolean a) {
        active = a;
        invalidate();
    }

    @Override
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h / 2f;
        float r = Math.min(w, h) / 2f * 0.80f;
        boolean lit = active || isPressed();

        // Outer glow
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(cx, cy, r * 1.25f,
                new int[]{lit ? 0xAA5FD8FF : 0x5536A8E8, 0x00000000},
                new float[]{0.6f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r * 1.25f, p);

        // Glass sphere
        p.setShader(new RadialGradient(cx, cy + r * 0.45f, r * 1.25f,
                new int[]{lit ? 0xFF6FE6FF : 0xFF2F9BE8, 0xFF0E4A8A, 0xFF04132A},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r, p);

        // Sparkle mark (an original four-point star)
        float s = r * 0.52f, k = s * 0.22f;
        star.reset();
        star.moveTo(cx, cy - s);
        star.quadTo(cx + k, cy - k, cx + s, cy);
        star.quadTo(cx + k, cy + k, cx, cy + s);
        star.quadTo(cx - k, cy + k, cx - s, cy);
        star.quadTo(cx - k, cy - k, cx, cy - s);
        star.close();
        p.setShader(new LinearGradient(cx, cy - s, cx, cy + s,
                0xFFFFFFFF, lit ? 0xFFB9F6FF : 0xFF9FE3FF, Shader.TileMode.CLAMP));
        c.drawPath(star, p);

        // Top gloss highlight
        oval.set(cx - r * 0.72f, cy - r * 0.94f, cx + r * 0.72f, cy - r * 0.02f);
        p.setShader(new LinearGradient(0, oval.top, 0, oval.bottom,
                0xCCFFFFFF, 0x08FFFFFF, Shader.TileMode.CLAMP));
        c.drawOval(oval, p);

        // Rim
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1f, r * 0.06f));
        p.setColor(0xCC02101F);
        c.drawCircle(cx, cy, r, p);
        p.setStrokeWidth(Math.max(1f, r * 0.03f));
        p.setColor(0x66FFFFFF);
        c.drawCircle(cx, cy, r * 0.94f, p);
    }
}
